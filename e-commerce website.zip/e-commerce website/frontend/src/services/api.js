// frontend/src/services/api.js
import axios from 'axios';

const api = axios.create({
  baseURL: 'BACKEND KEY',  // Backend URL
  withCredentials: true,                 // Send cookies if needed
});

export default api;
