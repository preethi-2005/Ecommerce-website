import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => (
  <nav style={{ display: 'flex', gap: '1rem', padding: '1rem', backgroundColor: '#f0f0f0' }}>
    <Link to="/">Products</Link>
    <Link to="/cart">Cart</Link>
    <Link to="/login">Login</Link>
    <Link to="/signup">Signup</Link>
  </nav>
);

export default Navbar;
