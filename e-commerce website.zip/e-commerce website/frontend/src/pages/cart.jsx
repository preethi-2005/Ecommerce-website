import React, { useEffect, useState } from 'react';
import api from '../services/api';

function Cart() {
  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    api.get('/cart')
      .then((res) => setCartItems(res.data))
      .catch((err) => console.error('Error fetching cart:', err));
  }, []);

  return (
    <div>
      <h2>Your Cart</h2>
      {cartItems.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <ul>
          {cartItems.map((item) => (
            <li key={item._id}>
              <p>{item.product.name} - Quantity: {item.quantity}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default Cart;
